<?php

namespace App\Http\Traits\Supply;

use App\Lib\SHCSLib;
use App\Lib\CheckLib;
use App\Model\Engineering\e_project;
use App\Model\Supply\b_supply_car_type;
use App\Model\Supply\b_supply_engineering_identity;
use App\Model\Supply\b_supply_member_l;
use App\Model\Supply\b_supply_rp_bcust;
use App\Model\Supply\b_supply_rp_car;
use App\Model\Supply\b_supply_rp_member_l;
use App\Model\Supply\b_supply_rp_project;
use App\Model\Supply\b_supply_rp_project_license;
use App\Model\User;
use Storage;
use Lang;

/**
 * 承攬商_申請_加入工程案件之工程身分
 *
 */
trait SupplyRPProjectLicenseTrait
{
    /**
     * 新增 承攬商_申請_加入工程案件之工程身分
     * @param $data
     * @param int $mod_user
     * @return bool
     */
    public function createSupplyRPProjectMemberLicense($data,$mod_user = 1)
    {
        $ret = false;
        if(is_array($data)) $data = (object)$data;
        if(!isset($data->b_supply_id)) return $ret;
        $now = date('Y-m-d H:i:s');

        $INS = new b_supply_rp_project_license();
        $INS->apply_user                = $mod_user;
        $INS->apply_stamp               = $now;
        $INS->b_supply_id               = $data->b_supply_id;
        $INS->b_cust_id                 = $data->b_cust_id;
        $INS->e_project_id              = $data->e_project_id;
        $INS->b_supply_member_l_id      = $data->b_supply_member_l_id;
        $INS->engineering_identity_id   = $data->engineering_identity_id;
        $INS->charge_kind               = b_supply_engineering_identity::getChargeKind($data->engineering_identity_id);
        $INS->e_license_id              = b_supply_member_l::getLicenseID($data->b_supply_member_l_id);

        $INS->new_user      = $mod_user;
        $INS->mod_user      = $mod_user;
        $ret = ($INS->save())? $INS->id : 0;

        return $ret;
    }
    /**
     * 修改 承攬商_申請_加入工程案件之工程身分
     * @param $id
     * @param $data
     * @param int $mod_user
     * @return bool
     */
    public function updateSupplyRPProjectMemberLicense($data,$mod_user = 1)
    {
        $ret = 0;
        $identityAry = $data['identity'];

        foreach ($identityAry as $val)
        {
            $id = $val['id'];
            $b_supply_rp_project_license_id = $val['b_supply_rp_project_license_id'];
            $tmp = [];
            if(in_array($id,[1,2]))
            {
                $tmp['aproc'] = 'P';
                $tmp['charge_memo'] = '';
            } else {
                $tmp['aproc'] = 'O';
                $tmp['charge_memo'] = '';
            }
            if($this->setSupplyRPProjectMemberLicense($b_supply_rp_project_license_id,$tmp,$mod_user)) $ret++;
        }
        return $ret;
    }

    /**
     * 修改 承攬商_申請_加入工程案件之工程身分
     * @param $id
     * @param $data
     * @param int $mod_user
     * @return bool
     */
    public function setSupplyRPProjectMemberLicense($id,$data,$mod_user = 1)
    {
        $ret = false;
        if(!$id || !count($data)) return $ret;
        if(is_array($data)) $data = (object)$data;
        $now = date('Y-m-d H:i:s');
        $aprocAry = array_keys(SHCSLib::getCode('RP_PROJECT_LICENSE_APROC'));
        $isUp = 0;

        $UPD = b_supply_rp_project_license::find($id);
        if(!isset($UPD->b_cust_id)) return $ret;
        if(isset($data->b_cust_id) && $data->b_cust_id !== $UPD->b_cust_id)
        {
            $UPD->b_cust_id   = $data->b_cust_id;
            $isUp++;
        }
        if(isset($data->b_supply_member_l_id) && $data->b_supply_member_l_id !== $UPD->b_supply_member_l_id)
        {
            $UPD->b_supply_member_l_id   = $data->b_supply_member_l_id;
            $isUp++;
        }
        //審查結果
        if(isset($data->aproc) && in_array($data->aproc,$aprocAry) && $data->aproc !== $UPD->aproc)
        {
            $isOK = 0;

            //審查通過
            if($data->aproc == 'O')
            {
                $data->e_project_id                     = $UPD->e_project_id;
                $data->b_supply_id                      = $UPD->b_supply_id;
                $data->b_cust_id                        = $UPD->b_cust_id;
                $data->b_supply_member_l_id             = $UPD->b_supply_member_l_id;
                $data->engineering_identity_id          = $UPD->engineering_identity_id;
                $data->b_supply_rp_project_license_id   = $id;
                if($this->createEngineeringMemberIdentity($data,$mod_user))
                {
                    $isOK = 1;
                }
            } else {
                $isOK = 1;
            }
            if($isOK)
            {
                $isUp++;
                //監造審查完畢
                if($UPD->aproc == 'P')
                {
                    $UPD->charge_user2   = $mod_user;
                    $UPD->charge_stamp2  = $now;
                    $UPD->charge_memo2   = isset($data->charge_memo)? $data->charge_memo : '';
                } else {
                    $UPD->charge_user1   = $mod_user;
                    $UPD->charge_stamp1  = $now;
                    $UPD->charge_memo1   = isset($data->charge_memo)? $data->charge_memo : '';
                }
                $UPD->aproc         = $data->aproc;
            }
        }
        //作廢
        if(isset($data->isClose) && in_array($data->isClose,['Y','N']) && $data->isClose !==  $UPD->isClose)
        {
            $isUp++;
            if($data->isClose == 'Y')
            {
                $UPD->isClose       = 'Y';
                $UPD->close_user    = $mod_user;
                $UPD->close_stamp   = $now;
            } else {
                $UPD->isClose = 'N';
            }
        }

        if($isUp)
        {
            $UPD->mod_user = $mod_user;
            $ret = $UPD->save();
        } else {
            $ret = -1;
        }

        return $ret;
    }

    /**
     * 取得 承攬商_成員申請單 by 承攬商
     *
     * @return array
     */
    public function getApiSupplyRPProjectMemberLicenseMainList($aproc = 'A',$allowAry = [], $isCount = 'N')
    {
        $ret  = ($isCount == 'Y')? 0 : [];
        $data = b_supply_rp_project_license::
        selectRaw('b_supply_id,count(b_supply_id) as amt')->where('isClose','N')->
        where('b_cust_id','>',0)->groupby('b_supply_id');

        if(is_array($allowAry) && count($allowAry))
        {
            $data = $data->whereIn('e_project_id',$allowAry);
        }
        if($aproc)
        {
            $data = $data->where('aproc',$aproc);
            if($aproc == 'P')
            {
                $data = $data->where('charge_kind',2);
            }
        }
        $data = $data->get();
        if(is_object($data)) {
            if($isCount == 'Y')
            {
                foreach ($data as $val)
                {
                    $ret += $val->amt;
                }
            } else {
                $ret = (object)$data;
            }

        }
        return $ret;
    }

    /**
     * 取得 承攬商_申請_加入工程案件之工程身分
     *
     * @return array
     */
    public function getApiSupplyRPProjectMemberLicenseList($sid,$aproc = 'A',$allowAry = [])
    {
        $ret = array();
        $aprocAry       = SHCSLib::getCode('RP_PROJECT_LICENSE_APROC');
        $chargekindAry  = SHCSLib::getCode('IDENTITY_CHARGE_KIND');
        //取第一層
        $data = b_supply_rp_project_license::
        join('e_project as p','p.id','=','b_supply_rp_project_license.e_project_id')->
        where('b_supply_rp_project_license.b_supply_id',$sid)->
        where('b_supply_rp_project_license.aproc',$aproc)->where('b_supply_rp_project_license.isClose','N')->
        where('b_supply_rp_project_license.b_cust_id','>',0)->
        select('b_supply_rp_project_license.*','p.name as project');
        if(is_array($allowAry) && count($allowAry))
        {
            $data = $data->whereIn('b_supply_rp_project_license.e_project_id',$allowAry);
        }
        if($aproc == 'P')
        {
            $data = $data->where('b_supply_rp_project_license.charge_kind',2);
        }

        $data = $data->get();
        if(is_object($data))
        {
            foreach ($data as $k => $v)
            {
                $id = $v->id;

                $data[$k]['charge_kind_name']   = isset($chargekindAry[$v->charge_kind])? $chargekindAry[$v->charge_kind] : '';
                $data[$k]['aproc_name']         = isset($aprocAry[$v->aproc])? $aprocAry[$v->aproc] : '';
                $data[$k]['engineering_identity_name']     = b_supply_engineering_identity::getName($v->engineering_identity_id);
                $data[$k]['apply_name']     = User::getName($v->apply_user);
                $data[$k]['apply_stamp']    = substr($v->apply_stamp,0,16);
                $data[$k]['charge_name1']   = User::getName($v->charge_user1);
                $data[$k]['charge_stamp1']  = substr($v->charge_stamp1,0,16);
                $data[$k]['charge_name2']   = User::getName($v->charge_user2);
                $data[$k]['charge_stamp2']  = substr($v->charge_stamp2,0,16);
                $data[$k]['user']           = User::getName($v->b_cust_id);
                $data[$k]['project']        = e_project::getName($v->e_project_id);
                $data[$k]['chg_user']       = User::getName($v->close_user);
                $data[$k]['new_user']       = User::getName($v->new_user);
                $data[$k]['mod_user']       = User::getName($v->mod_user);
            }
            $ret = (object)$data;
        }

        return $ret;
    }
    /**
     * 取得 承攬商_申請_加入工程案件之工程身分
     *
     * @return array
     */
    public function getApiSupplyRPProjectMemberLicenseIDFroRpMember($sid,$b_supply_rp_member_id)
    {
        //取第一層
        $ret = [];
        $data = b_supply_rp_project_license::where('b_supply_id',$sid)->where('b_supply_rp_member_id',$b_supply_rp_member_id)->
        where('aproc','A')->where('isClose','N')->
        where('b_supply_rp_member_id',0)->select('id','engineering_identity_id');
        if($data->count())
        {
            foreach ($data->get() as $val)
            {
                $tmp = [];
                $tmp['id'] = $val->id;
                $tmp['engineering_identity_id'] = $val->engineering_identity_id;
                $tmp['engineering_identity_name'] = b_supply_engineering_identity::getName($val->engineering_identity_id);
                $ret[] = $tmp;
            }
        }

        return $ret;
    }

}
