<?php

namespace App\Http\Traits\Supply;

use App\Lib\SHCSLib;
use App\Lib\CheckLib;
use App\Model\Factory\b_car_type;
use App\Model\Supply\b_supply_rp_car;
use App\Model\User;
use Storage;
use Lang;

/**
 * 承攬商_車輛申請
 *
 */
trait SupplyRPCarTrait
{

    /**
     * 修改 車輛申請
     * @param $id
     * @param $data
     * @param int $mod_user
     * @return bool
     */
    public function setSupplyRPCar($id,$data,$mod_user = 1)
    {
        $ret = false;
        if(!$id || !count($data)) return $ret;
        if(is_array($data)) $data = (object)$data;
        $aprocAry = array_keys(SHCSLib::getCode('RP_SUPPLY_CAR_APROC'));
        $now = date('Y-m-d H:i:s');
        $isUp = 0;

        $UPD = b_supply_rp_car::find($id);
        if(!isset($UPD->car_no)) return $ret;
        $filepath   = config('mycfg.supply_car_apth').'RP/'.date('Y/').$id.'/';
        //車牌
        if(isset($data->car_no) && ($data->car_no) && $data->car_no !== $UPD->car_no)
        {
            $isUp++;
            $UPD->car_no = $data->car_no;
        }
        //車牌
        if(isset($data->car_memo) && ($data->car_memo) && $data->car_memo !== $UPD->car_memo)
        {
            $isUp++;
            $UPD->car_memo = $data->car_memo;
        }

        //車分類
        if(isset($data->car_type) && ($data->car_type) && $data->car_type !== $UPD->car_type)
        {
            $isUp++;
            $UPD->car_type = $data->car_type;
        }
        //有效日期
        if(isset($data->sdate) && CheckLib::isDate($data->sdate) && $data->sdate !== $UPD->sdate)
        {
            $isUp++;
            $UPD->sdate = $data->sdate;
        }
        //有效日期
        if(isset($data->last_car_inspection_date) && CheckLib::isDate($data->last_car_inspection_date) && $data->last_car_inspection_date !== $UPD->last_car_inspection_date)
        {
            $isUp++;
            $UPD->last_car_inspection_date = $data->last_car_inspection_date;
        }
        //有效日期
        if(isset($data->last_exhaust_inspection_date) && CheckLib::isDate($data->last_exhaust_inspection_date) && $data->last_exhaust_inspection_date !== $UPD->last_exhaust_inspection_date)
        {
            $isUp++;
            $UPD->last_exhaust_inspection_date = $data->last_exhaust_inspection_date;
        }
        //有效日期
        if(isset($data->last_exhaust_inspection_date2) && CheckLib::isDate($data->last_exhaust_inspection_date2) && $data->last_exhaust_inspection_date2 !== $UPD->last_exhaust_inspection_date2)
        {
            $isUp++;
            $UPD->last_exhaust_inspection_date2 = $data->last_exhaust_inspection_date2;
        }
        //證照檔案
        if(isset($data->file1) && ($data->file1) && $data->file1N)
        {
            $filename = $id.'_A.'.$data->file1N;
            $file    = $filepath.$filename;
            if(Storage::put($file,$data->file1))
            {
                $isUp++;
                $UPD->file1 = $file;
            }
        }
        //證照檔案
        if(isset($data->file2) && ($data->file2) && $data->file2N)
        {
            $filename = $id.'_B.'.$data->file2N;
            $file    = $filepath.$filename;
            if(Storage::put($file,$data->file2))
            {
                $isUp++;
                $UPD->file2 = $file;
            }
        }
        //證照檔案
        if(isset($data->file3) && ($data->file3) && $data->file3N)
        {
            $filename = $id.'_C.'.$data->file3N;
            $file    = $filepath.$filename;
            if(Storage::put($file,$data->file3))
            {
                $isUp++;
                $UPD->file3 = $file;
            }
        }

        //審查結果
        if(isset($data->aproc) && in_array($data->aproc,$aprocAry) && $data->aproc !== $UPD->aproc)
        {
            $isOK = 0;
            //審查通過
            if($data->aproc == 'O')
            {
                $data->car_no       = $UPD->car_no;
                $data->car_memo     = $UPD->car_memo;
                $data->car_type     = $UPD->car_type;
                $data->img_path     = $UPD->img_path;
                $data->filepath1    = $UPD->file1;
                $data->filepath2    = $UPD->file2;
                $data->filepath3    = $UPD->file3;
                $data->e_project_id = $UPD->e_project_id;
                if($this->createCar($data,$mod_user))
                {
                    $isOK = 1;
                }
            } else {
                $isOK = 1;
            }
            if($isOK)
            {
                $isUp++;
                //監造審查完畢
                if($UPD->aproc == 'P')
                {
                    $UPD->charge_user2   = $mod_user;
                    $UPD->charge_stamp2  = $now;
                    $UPD->charge_memo2   = $data->charge_memo;
                } else {
                    $UPD->charge_user1   = $mod_user;
                    $UPD->charge_stamp1  = $now;
                    $UPD->charge_memo1   = $data->charge_memo;
                }
                $UPD->aproc         = $data->aproc;
            }
        }

        if($isUp)
        {
            $UPD->mod_user = $mod_user;
            $ret = $UPD->save();
        } else {
            $ret = -1;
        }

        return $ret;
    }


    /**
     * 取得 車輛申請 by 承攬商
     *
     * @return array
     */
    public function getApiSupplyRPCarMainList($aproc = 'A',$allowProject = [])
    {
        $data = b_supply_rp_car::join('b_supply as s','s.id','=','b_supply_rp_car.b_supply_id')->
        selectRaw('MAX(s.id) as b_supply_id,MAX(s.name) as b_supply,MAX(s.tel1) as tel1,count(s.id) as amt')->
        groupby('b_supply_id');

        if($aproc)
        {
            $data = $data->where('aproc',$aproc);
        }
        if(count($allowProject))
        {
            $data = $data->whereIn('e_project_id',$allowProject);
        }
        $data = $data->get();
        if(is_object($data)) {
            $ret = (object)$data;
        }
        return $ret;
    }

    /**
     * 取得 車輛申請
     *
     * @return array
     */
    public function getApiSupplyRPCarList($sid,$aproc = 'A',$allowProject = [])
    {
        $ret = array();
        $typeAry  = b_car_type::getSelect();
        $aprocAry = SHCSLib::getCode('RP_SUPPLY_CAR_APROC');
        //取第一層
        $data = b_supply_rp_car::join('e_project as p','p.id','=','b_supply_rp_car.e_project_id')->
                join('b_supply as s','s.id','=','b_supply_rp_car.b_supply_id')->
                select('b_supply_rp_car.*','p.name as project','p.project_no','p.edate as project_edate','s.name as supply')->
                where('b_supply_rp_car.b_supply_id',$sid)->where('b_supply_rp_car.aproc',$aproc);
        if(count($allowProject))
        {
            $data = $data->whereIn('p.id',$allowProject);
        }
        $data = $data->get();
        if(is_object($data))
        {
            foreach ($data as $k => $v)
            {
                $id        = $v->id;
                $filePath1 = strlen($v->file1)? storage_path('app'.$v->file1) : '';
                $filePath2 = strlen($v->file2)? storage_path('app'.$v->file2) : '';
                $filePath3 = strlen($v->file3)? storage_path('app'.$v->file3) : '';
                $imgPath   = strlen($v->img_path)? storage_path('app'.$v->img_path) : '';

                $data[$k]['img_path']  = ($imgPath && file_exists($imgPath))? SHCSLib::url('img/RpCar/',$id,'sid=D') : '';
                $data[$k]['filePath1'] = ($filePath1 && file_exists($filePath1))? SHCSLib::url('img/RpCar/',$id,'sid=A') : '';
                $data[$k]['filePath2'] = ($filePath2 && file_exists($filePath2))? SHCSLib::url('img/RpCar/',$id,'sid=B') : '';
                $data[$k]['filePath3'] = ($filePath3 && file_exists($filePath3))? SHCSLib::url('img/RpCar/',$id,'sid=C') : '';

                $data[$k]['car_type_name']  = isset($typeAry[$v->car_type])? $typeAry[$v->car_type] : '';
                $data[$k]['aproc_name']     = isset($aprocAry[$v->aproc])? $aprocAry[$v->aproc] : '';
                $data[$k]['apply_name']     = User::getName($v->apply_user);
                $data[$k]['apply_stamp']    = substr($v->apply_stamp,0,16);
                $data[$k]['charge_name1']   = User::getName($v->charge_user1);
                $data[$k]['charge_stamp1']  = substr($v->charge_stamp1,0,16);
                $data[$k]['charge_name2']   = User::getName($v->charge_user2);
                $data[$k]['charge_stamp2']  = substr($v->charge_stamp2,0,16);
                $data[$k]['chg_user']       = User::getName($v->close_user);
                $data[$k]['new_user']       = User::getName($v->new_user);
                $data[$k]['mod_user']       = User::getName($v->mod_user);
            }
            $ret = (object)$data;
        }

        return $ret;
    }

}
