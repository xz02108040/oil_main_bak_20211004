<?php

namespace App\Http\Controllers;


use App\Http\Traits\BcustTrait;
use App\Http\Traits\SessTraits;
use App\Http\Traits\Supply\SupplyRPProjectLicenseTrait;
use App\Http\Traits\WorkPermit\WorkPermitWorkOrderTrait;
use App\Lib\ContentLib;
use App\Lib\FormLib;
use App\Lib\HtmlLib;
use App\Lib\LogLib;
use App\Lib\TableLib;
use App\Lib\TokenLib;
use App\Model\Engineering\e_project;
use App\Model\sys_param;
use Illuminate\Http\Request;
use Session;
use Lang;
use Auth;

class TestSQLController extends Controller
{
    use SessTraits,BcustTrait;
    /*
    |--------------------------------------------------------------------------
    | TestSQLController
    |--------------------------------------------------------------------------
    |
    | Test SQL
    | 高風險 限定
    |
    */

    /**
     * 環境參數
     */
    protected $redirectTo = '/';

    /**
     * 建構子
     */
    public function __construct()
    {
        //身分驗證
        $this->middleware('auth');

        //路由
        $this->hrefHome      = '/testsql';
        $this->routerPost    = 'testsql';

    }
    /**
     * 首頁內容
     *
     * @return void
     */
    public function index(Request $request)
    {
        //讀取 Session 參數
        $this->getBcustParam();
        $this->getMenuParam();
        //POST
        if($request->sqltest && strlen($request->sqltest) > 10)
        {
            $result = \DB::select($request->sqltest);
            dd($result);
        }
        //-------------------------------------------//
        //View
        //-------------------------------------------//
        //Form
        $form = new FormLib(1,array($this->routerPost,-1),'POST',1,TRUE);
        if($request->key == 'Httc@24508323')
        {
            //SQL
            $html = $form->textarea('sqltest','','',$request->sqltest);
            $form->add('nameT1', $html,'SQL');
            //Submit
            $submitDiv  = $form->submit(Lang::get('sys_btn.btn_8'),'1','agreeY').'&nbsp;';
            $form->boxFoot($submitDiv);
        }


        $out = $form->output();


        //-------------------------------------------//
        //  View -> out
        //-------------------------------------------//
        $content = new ContentLib();
        $content->rowTo($content->box_form('Httc', $out,2));
        $contents = $content->output();
        //-------------------------------------------//
        //  回傳
        //-------------------------------------------//
        $retArray = ["title"=>'SQL TEST','content'=>$contents,'menu'=>$this->sys_menu];

        return view('index',$retArray);
    }
}
