<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    // 定義應用程式的 Artisan 指令
    protected $commands = [
        Commands\CourseOverDateQueue::class,
        Commands\CoursePassQueue::class,
        Commands\IdentityOverDateQueue::class,
        Commands\ProjectOverDateQueue::class,
        Commands\ProjectPassQueue::class,
        Commands\DoorInoutQueue::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        //1. 產生 教育訓練資格 通過<每60分鐘檢查>
        $schedule->command('httc:coursepass')->hourlyAt('15')->withoutOverlapping();
        //2. 產生 教育訓練 過期<每天 00:10>
        $schedule->command('httc:courseoverdate')->dailyAt('00:10')->withoutOverlapping();
        //3. 產生 承攬身份 過期<每天 00:15>
        //$schedule->command('httc:identityoverdate')->dailyAt('00:15')->withoutOverlapping();
        //4. 產生 承攬項目 過期<每天 00:20>
        $schedule->command('httc:projectoverdate')->dailyAt('00:20')->withoutOverlapping();
        //5. 產生 承攬身分資格 通過<每60分鐘檢查>
        $schedule->command('httc:projectpass')->hourlyAt('30')->withoutOverlapping();
        //6. 產生 承攬商進出累計工時表 通過<每天 11:00>
        $schedule->command('httc:doorinoutrept')->dailyAt('11:00')->withoutOverlapping();

        //104. 通知 當日工作許可證定期離場通知 <每天 一個小時>
        //$schedule->command('httc:permitworkpush4')->hourlyAt('45')->withoutOverlapping();

    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
